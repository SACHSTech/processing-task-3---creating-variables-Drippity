import processing.core.PApplet;

public class Sketch extends PApplet {

  public void settings() {
    size(500,500);
  }

  public void setup() {
    background(204,204,255);
  }

  public void draw() {
    float rect1 = 50; //rectangle X Coordinates
    float rect2 = 100; //rectangle Y Coordinates
    float size1 = 80; //rectangle size
    float size2 = 20; //vertical length of eyes and horizontal width of mouth
    float size3 = 2; //horizontal width of eyes
    float size4 = 5; //vertical length of mouth
    float eye1 = 115; //eye X Coordinates
    float eye2 = 65; //eye Y Coordinates
    
    fill(255,155,0);
    rect(rect1,rect2,size1,size1); //Head
    fill(0);
    rect(eye1,eye1,size3,size2); //Eye on the Right
    fill(0);
    rect(eye2,eye1,size3,size2); //Eye on the Left
    fill(0);
    ellipse(size1,size1*2,size2,size4); //Mouth
  }
}